export const NOT_SPECIFIED = "*";

export enum COMPARE_MODE {
    GREATER_THAN_EQUALS = ">=",
    STRICT_EQUALS = "=="
}