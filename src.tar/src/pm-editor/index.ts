// Export class
export { CoqEditorProvider } from "./coqEditor";
